import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pointlist',
  templateUrl: './pointlist.component.html',
  styleUrls: ['./pointlist.component.css']
})
export class PointlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

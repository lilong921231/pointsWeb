import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pointinfo',
  templateUrl: './pointinfo.component.html',
  styleUrls: ['./pointinfo.component.css']
})
export class PointinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

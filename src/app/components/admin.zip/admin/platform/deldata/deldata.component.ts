import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deldata',
  templateUrl: './deldata.component.html',
  styleUrls: ['./deldata.component.css']
})
export class DeldataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

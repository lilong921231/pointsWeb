import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usershow',
  templateUrl: './usershow.component.html',
  styleUrls: ['./usershow.component.css']
})
export class UsershowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

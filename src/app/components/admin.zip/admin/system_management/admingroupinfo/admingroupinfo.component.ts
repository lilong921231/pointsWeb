import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admingroupinfo',
  templateUrl: './admingroupinfo.component.html',
  styleUrls: ['./admingroupinfo.component.css']
})
export class AdmingroupinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

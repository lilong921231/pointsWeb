import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingroupinfoComponent } from './admingroupinfo.component';

describe('AdmingroupinfoComponent', () => {
  let component: AdmingroupinfoComponent;
  let fixture: ComponentFixture<AdmingroupinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmingroupinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmingroupinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

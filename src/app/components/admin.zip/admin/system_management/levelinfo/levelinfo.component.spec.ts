import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LevelinfoComponent } from './levelinfo.component';

describe('LevelinfoComponent', () => {
  let component: LevelinfoComponent;
  let fixture: ComponentFixture<LevelinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LevelinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LevelinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

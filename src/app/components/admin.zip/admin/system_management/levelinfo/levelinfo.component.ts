import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-levelinfo',
  templateUrl: './levelinfo.component.html',
  styleUrls: ['./levelinfo.component.css']
})
export class LevelinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

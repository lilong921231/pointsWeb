import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admingroup',
  templateUrl: './admingroup.component.html',
  styleUrls: ['./admingroup.component.css']
})
export class AdmingroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

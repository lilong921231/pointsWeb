import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tb-index-kline',
  templateUrl: './tb-index-kline.component.html',
  styleUrls: ['./tb-index-kline.component.css']
})
export class TbIndexKlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

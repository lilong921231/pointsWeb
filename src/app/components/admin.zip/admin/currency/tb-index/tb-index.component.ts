import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tb-index',
  templateUrl: './tb-index.component.html',
  styleUrls: ['./tb-index.component.css']
})
export class TbIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-repass-spw',
  templateUrl: './repass-spw.component.html',
  styleUrls: ['./repass-spw.component.css']
})
export class RepassSpwComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  /**
   * 修改密码
   * 核查input有没有值存在
   */
  checkInput() {
    // 检查旧密码是否为空
    if ($('#oldpass').val() === null || $('#oldpass').val() === '') {
      alert('请输入原密码!');
      return false;
    }
    // 检查新密码
    if ($('#password').val() === null || $('#password').val() === '') {
      alert('请输入新密码!');
      return false;
    }
    // 检查确认密码
    if ($('#password-2').val() === null || $('#password-2').val() === '') {
      alert('请输入确认密码');
      return false;
    }
    // 检查两次密码输入的是否一致
    if ($('#password').val() !== $('#password-2').val()) {
      alert('两次密码不一致!');
      return false;
    }
    // 检查密码是否小于6位
    if ($('#password').val().toLocaleString().length < 6 ) {
      alert('密码不能小于6位!');
      return false;
    }

  }
  /**
   * 重置事件
   */
  reset() {
    //  密码
    $('input[type="password"]').prop('value', '');
  }
}

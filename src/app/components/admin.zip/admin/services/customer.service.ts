import { Injectable } from '@angular/core';
import * as $ from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor() { }

  /**
  * 删除公告消息
  */
  del_new() {
    const new_select = confirm('确认删除？');
    if (new_select) {
      alert('您选择了确认删除信息');
    } else {
      return false;
    }
  }

  /**
   * 删除选定的公告消息
   */
  del_news() {
    const message = '确认删除以上1条记录？';
    const new_selects = confirm(message);
    if (new_selects) {
      alert('您选择了删除好几条信息');
    } else {
      return false;
    }
  }

  /**
   * 删除留言消息
   */
  del_meg() {
    const new_select = confirm('确认删除？');
    if (new_select) {
      alert('您选择了确认删除信息');
    } else {
      return false;
    }
  }

  /**
   * 删除选定的留言消息
   */
  del_megs() {
    const message = '确认删除以上1条记录？';
    const new_selects = confirm(message);
    if (new_selects) {
      alert('您选择了删除好几条信息');
    } else {
      return false;
    }
  }

  /**
   * 添加公告
   */
  new_add() {
    alert('保存成功');
  }

  /**
   * 修改公告
   */
  new_updata() {
    alert('保存成功');
  }

  /**
   * 修改管理员回复
   */
  meg_updata() {
    alert('保存成功');
  }

  /**
   * 清空单个input框按钮
   */
  button_empty(div_id) {
    //  清空标题
    $(div_id).prop('value', '');
  }

}

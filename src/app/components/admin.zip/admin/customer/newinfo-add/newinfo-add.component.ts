import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-newinfo-add',
  templateUrl: './newinfo-add.component.html',
  styleUrls: ['./newinfo-add.component.css']
})
export class NewinfoAddComponent implements OnInit {

  constructor(
    private customer: CustomerService
  ) { }

  ngOnInit() {
  }

/*  /!**
   * 添加公告
   *!/
  info_add() {
    alert('保存成功');
  }
}*/

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../../services/customer.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  constructor(
    private router: Router,
    private customer: CustomerService
  ) { }

  ngOnInit() {
  }

  /**
   * 跳转添加记录页面
   */
  info_add() {
    this.router.navigateByUrl('/admin/newinfo_add');
  }

 /* /!**
   * 删除公告消息
   *!/
  del_new() {
    const new_select = confirm('确认删除？');
    if (new_select) {
      alert('您选择了确认删除信息');
    } else {
      return false;
    }
  }

  /!**
   * 删除选定的公告消息
   *!/
  del_news() {
    const message = '确认删除以上1条记录？';
    const new_selects = confirm(message);
    if (new_selects) {
      alert('您选择了删除好几条信息');
    } else {
      return false;
    }*/
  //}
}
